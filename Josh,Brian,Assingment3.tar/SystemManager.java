/* 
 * Josh Richmond
 * Brian Lee
 */
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;




public class SystemManager {
	
	//Maps which will hold Ports,Companies, and Ships
	Map<String,Port> airports;
	Map<String,Port> seaports;
	Map<String, Company> airlines;
	Map<String, Company> cruiselines;
	Map<String, Ship> ships;
	
	//Initializes Maps when SystemManager is created
	public SystemManager(){
		airports = new HashMap<String,Port>();
		seaports = new HashMap<String,Port>();
		airlines = new HashMap<String,Company>();
		cruiselines = new HashMap<String,Company>();
		ships = new HashMap<String,Ship>();
	}
	
	/*Create Airport:
	 * 		Takes in a name of an airport and checks to see if that Airport already exists,
	 * 	    If it doesn't a new airport object is created and added to airports map.
	 * 		An error is thrown if the airport name is not 3 characters or already exists.
	 */
	public void createAirport(String n){
		if(!airports.containsKey(n)){
			Port airport = null;
			try {
				airport = new Port(n);
				airports.put(n,airport);
			} catch (IOException e) {
				System.err.println("Error: Failed to Create Airport " + n + ", Incorrect length (length must be 3 characters");
			}
			
		}else{
			System.err.println("Error: Airport " + n + " already exist");
		}
	}
	
	/*createSeaport:
	 *   Creates a seaport if name does not already exist and it is 3 characters
	 */
	public void createSeaport(String n){
		if(!seaports.containsKey(n)){
			Port seaport = null;
			try {
			    seaport = new Port(n);
				seaports.put(n,seaport);
			} catch (IOException e) {
				System.err.println("Error: Failed to Create seaport " + n + ", Incorrect length (length must be 3 characters)");
			}
			
		}else{
			System.err.println("Error: Airport " + n + " already exist");
		}
	}
	
	/*Create Airline:
	 * 	  	Takes in a name of an airline.
	 * 		If the airline does not already exist, an airline is created and added to the airlines map
	 */
	public void createAirline(String n){
		if(!airlines.containsKey(n)){
			Airline airline = null;
				airline = new Airline(n);
				airlines.put(n,airline);
			
		}else{
			System.err.println("Error: Airline " + n + " already exist");
		}
	}
	
	
	/*creatCruiseline:
	 *   Creates a cruiseline if name does not already exist
	 */
	public void createCruiseline(String n){
		if(!cruiselines.containsKey(n)){
			CruiseLine cruiseline = null;
				cruiseline = new CruiseLine(n);
				cruiselines.put(n,cruiseline);
			
		}else{
			System.err.println("Error: cruiselines " + n + " already exist");
		}
	}
	
	/*Create Flight:
	 * 		Creates a new flight object and adds it to the corresponding airlines flight map.
	 * 		An error is handled if the airline does not exist.
	 */
	public void createFlight(String airlineName, String[] sequence, int[] startDate, int[] endDate, String flID){
		if(airlines.containsKey(airlineName)){
			Trip flight = new Flight(airlineName,sequence, startDate, endDate, flID);
			 airlines.get(airlineName).addTrip(flight);
		}else{
			System.err.println("Error: Cannot create Flight ID:" + flID + " Airline:" + airlineName + " does not exist");
			
		}
	}
	
	/*createCruiseTrip
	 *   Similar to Flight, creates a cruise trips if trip id does not exist.
	 *   Check to make sure that the provided ship will not already be in use during the date window given
	 *   Also checks to make sure the departure date is before the return date
	 */
	@SuppressWarnings("deprecation")
	public void createCruiseTrip(String cruiseName, String[] sequence, int[] startDate, int[] endDate, String ID,String ship){
		Ship tempShip = ships.get(ship);
		if(!checkLength(startDate,endDate)){
			return;
		}
		if(cruiselines.containsKey(cruiseName)){
			for(Company c : cruiselines.values()){
				for(Trip t : c.getTrips().values()){
					if(((CruiseTrip) t).getShip() == tempShip){
						int temp[] = t.getStartDate();
						Date s1 = new Date(temp[2],temp[0],temp[1]);	
						temp = t.getEndDate();
						Date e1 = new Date(temp[2],temp[0],temp[1]);
						
						Date s2 = new Date(startDate[2],startDate[0],startDate[1]);
						Date e2 = new Date(endDate[2], endDate[0], endDate[1]);

						
						
						if(!(s1.after(e2)) && !(s2.after(e1))){
							System.err.println("That ship is is already asinged a trip for the given date");
							return;
						}
						
						
					}
				}
			}
			Trip cruise = new CruiseTrip(cruiseName,sequence, startDate, endDate, ID, tempShip);
			 cruiselines.get(cruiseName).addTrip(cruise);
			 System.out.println("Cruise Trip successfully created.");
		}else{
			System.err.println("Error: Cannot create cruise ID:" + ID + " cruiseline:" + cruiseName + " does not exist");
		}
	}
	
	/*checkLength:
	 *   Checks to make sure the length of a cruise is not over 21 days
	 */
	@SuppressWarnings("deprecation")
	private boolean checkLength(int[] startDate, int[] endDate) {
		Date start = new Date(startDate[2],startDate[0],startDate[1]);
		Date end = new Date(endDate[2],endDate[0],endDate[1]);
		if((end.getTime()-start.getTime())/(1000*60*60*24) > 21){
			System.err.println("Error: Trip lenth exceeds 21 days.");
			return false;
		}
		if(start.after(end)){
			System.err.println("Error: starting date is after ending date");
			return false;
		}
		return true;
		
		
	}

	/*createShip
	 *   Creates a ship if the given name is not already taken
	 */
	public void createShip(String shipID){
		if(ships.containsKey(shipID)){
			System.err.println("Error: ship already exists");
		}else{
			Ship ship = new Ship(shipID);
			ships.put(shipID, ship);
		}
	}
	

	/*createShipSection
	 *   Creates ship section on a given ship.
	 *   Will not create sections on ship if ship is already assigned to trips
	 */
	public void createShipSection(String companyName, String shipID, int rows, int cols, Class cabinClass){
		if(cruiselines.containsKey(companyName)){
			for(Company c : cruiselines.values()){
				for(Trip t : c.getTrips().values()){
					if(((CruiseTrip) t).getShip() == ships.get(shipID)){
						System.err.println("Error: cannot create sections on a ship already assigned trips");
						return;
					}
				}
			}
			Section shipSection = new CabinSection(companyName,shipID, rows, cols,cabinClass);
			ships.get(shipID).addSection(shipSection);
		}else{
			System.err.println("Error company does not exist");
		}
	}
	
	/*createsFlightSection
	 *   Creates a section on a flight as long as company and flight exist
	 */
	public void createFlightSection(String companyName, String flightID, int rows, int cols, Class seatClass){
		if(airlines.containsKey(companyName)){
			Section flightSection = new FlightSection(companyName,flightID, rows, cols,seatClass);
			((Flight) airlines.get(companyName).getTrip(flightID)).addSection(flightSection);
		}else{
			System.err.println("Error company does not exist");
		}
	}
	
	/*bookSeat:
	 *   Books a Seat as long as the company,flight, and flight section exist
	 */
	public void bookSeat(String company, String flID, Class s, int row, char col) throws IOException{
		if(airlines.containsKey(company)){
			Accommodation seat = new Seat(row,col);
			try{
				airlines.get(company).getTrip(flID).getSection(s).bookAccomodation(seat);
			}catch(IOException e){
			}
		}else{
			System.err.println("error: company does not exist");
		}
	}
	
	/*bookCabin
	 *   Books cabin as long as company, trip, and section exist
	 */
	public void bookCabin(String company, String tripID, Class c, int row, char col){
		if(cruiselines.containsKey(company)){
			Accommodation cabin = new Cabin(row,col);

			try {
				cruiselines.get(company).getTrip(tripID).getSection(c).bookAccomodation(cabin);
			} catch (IOException e) {
			}
		}
	}
	
	/*airlineState:
	 *   Calls the displayDetails() method for each airline, to print out the state of the Airline subsystem
	 */
	public void airlineState(){
		System.out.println("Airline Subsystem Information");
		for(Company airline : airlines.values()){
			airline.displayDetails();
		}
	}
	
	/*cruiselineState:
	 *   Calls the displayDetails() method for each cruisline, to prinnt out the state of the cruiseline subsystem
	 */
	public void cruiselineState(){
		System.out.println("Cruiseline Substystem Information");
		for (Company cruiseline : cruiselines.values()){
			cruiseline.displayDetails();
		}
	}
	
	/*getAvailableCabins
	 *   If there are cruiselines it will check to see if there are available cabins
	 */
	public void getAvailableCabins(){
		System.out.println("Available Accomodations on cruises:");
		if (cruiselines.isEmpty()){
			System.out.println("\tnone");
		}else{
			for(Company c : cruiselines.values()){
				c.findAvailable();
			}
		}
	}
	
	/*getAvailableSeats()
	 *   If there are airlines it will check to see if there are available seats
	 */
	public void getAvailableSeats(){
		System.out.println("Available Accomodations on cruises:");
		if (airlines.isEmpty()){
			System.out.println("\tnone");
		}else{
			for(Company a : airlines.values()){
				a.findAvailable();
			}
		}
	}
	
	/*getCruisline:
	 *   returns cruiseline with name provided
	 */
	public Company getCruiseline(String cruiseline){
		return cruiselines.get(cruiseline);
	}
	

	public Company getAirline(String airline){
		return airlines.get(airline);
	}
	
	// checks to see if trip exist
	public boolean doesTripExist(Company c, String tripID){
		if (c.getTrip(tripID) != null){
			return true;
		}
		return false;
	}
	
	// checks to see if an airport exist
	public boolean doesAirportExist(String port){
		if (airports.get(port) != null){
			return true;
		}
		return false;
	}
	
	// checks to see if a seaport exist
	public boolean doesSeaportExist(String port){
		if (seaports.get(port) != null){
			return true;
		}
		return false;
	}
	
	// checks to see if a seaport exist
	public boolean doesShipExist(String shipName){
		if (ships.get(shipName) != null){
			return true;
		}
		return false;
	}
	
}
