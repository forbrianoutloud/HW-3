/* 
 * Josh Richmond
 * Brian Lee
 */


// Invokes super class Trip and can add section
public class Flight extends Trip{

	public Flight(String companyName, String[] sequence, int[] startDate,
			int[] endDate, String tripID) {
		super(companyName, sequence, startDate, endDate, tripID);
		// TODO Auto-generated constructor stub
	}
	
	public void addSection(Section section){
		if(!sections.containsKey( section.getclass())){
			sections.put(section.getclass(), section);
		}else{
			System.err.println("Error, Section already exists withing flight");
		}
	}
}
	
