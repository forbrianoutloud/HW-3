/* 
 * Josh Richmond
 * Brian Lee
 */

//Invokes super class Accommodation
public class Seat extends Accommodation{
	public Seat(int row, char col) {
		super(row, col);
	}
	
	
}
