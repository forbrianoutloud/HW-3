//Invokes super class Section
public class CabinSection extends Section{
	public CabinSection(String companyName, String ID, int rows, int cols, Class cabinClass) {
			super(companyName, ID, rows, cols, cabinClass);
	}

}
