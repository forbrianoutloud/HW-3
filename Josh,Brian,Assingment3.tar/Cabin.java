//invokes super class Accommodation
public class Cabin extends Accommodation{
	public Cabin(int row, char col) {
		super(row, col);
	}
}
