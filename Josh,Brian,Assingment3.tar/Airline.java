/* 
 * Josh Richmond
 * Brian Lee
 */

//invokes super class Company
public class Airline extends Company {
	
	public Airline(String name) {
		super(name);
	}
}
