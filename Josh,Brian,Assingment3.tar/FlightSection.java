/* 
 * Josh Richmond
 * Brian Lee
 */


//Invokes super class Section
public class FlightSection extends Section{
	public FlightSection(String companyName, String ID, int rows, int cols, Class s) {
		super(companyName, ID, rows, cols, s);
	}

}
