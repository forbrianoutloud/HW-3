

/* 
 * Josh Richmond
 * Brian Lee
 */
		
		
    /* This Class is used to instantiate a few things before the program ask the user to login
     * Makes pre-created trips that the user can interact with to get an idea of how the system works */ 
	public class ClientProg{
		
		public void createStuff(SystemManager res){
			String[] tempSeq;
			int[] startDate;
			int[] endDate;
			res.createAirport("DEN");
			res.createAirport("DFW");	
			res.createAirport("LON");
			res.createAirport("JPN");
			
			res.createSeaport("ss1");
			res.createSeaport("ss2");
			res.createSeaport("ss3");
			
			res.createAirline("DELTA");
			res.createAirline("AMER");
			res.createCruiseline("Carnival");
			res.createCruiseline("cruiseline");
			
			tempSeq = new String[]{"DEN","DFW"};
			startDate = new int[]{12,27,1993};
			endDate = new int[]{12,27,1993};
			
			res.createFlight("DELTA",tempSeq, startDate, endDate, "123");
			
			tempSeq = new String[]{"ss1","ss2","ss3"};
			startDate = new int[]{5,28,2015};
			endDate = new int[]{6,15,2015};		
			
			res.createShip("testShip");		
			res.createShipSection("Carnival", "testShip", 2, 2, Class.couples);
			res.createShipSection("Carnival", "testShip", 8, 2, Class.family);
			
			
			res.createCruiseTrip("Carnival", tempSeq, startDate, endDate, "124","testShip");
			tempSeq = new String[]{"ss1","ss2"};
			startDate = new int[]{6,16,2015};
			endDate = new int[]{6,20,2015};
			res.createCruiseTrip("Carnival", tempSeq, startDate, endDate, "125", "testShip");
			
	
	
	
			res.createFlightSection("DELTA", "123"	, 2, 2, Class.business);

		}
	}
