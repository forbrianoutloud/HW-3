//Invokes super class Company
public class CruiseLine extends Company {

	public CruiseLine(String name) {
		super(name);
	}


}
