/* Invokes super class Trip
 * has added methods to handle ships that are associated with cruiseTrips
 */
public class CruiseTrip extends Trip{
	Ship ship;
	public CruiseTrip(String companyName, String[] sequence, int[] startDate, int[] endDate, String tripID, Ship ship) {
		super(companyName, sequence, startDate, endDate, tripID);
		addShip(ship);
	}
	
	public void addShip(Ship ship){
		this.ship = ship;
		for(Section s : ship.getSections().values()){
			Section temp = new CabinSection(s.getCompanyName(),s.getID(),s.getRows(),s.getCols(),  s.getclass());
			sections.put( s.getclass(), temp);
		}
	}
	
	public Ship getShip(){
		return ship;
	}
	
	/*Differs from diplayDetails in Trip because it needs to show which ship
	 * is used for each trip */
	public void diplayDetails(){
		System.out.println("    Trip ID: " + getTripID());
		System.out.println("      Ship: " + ship.getShipID());
		System.out.print("      Route - ");
		int i = 0;
		for(i = 0; i < getSequence().length - 1;i++){
			System.out.print(getSequence()[i] + " -> " );
		}
		System.out.println(getSequence()[i]);
		
		System.out.print("      StartDate: ");
		for(i = 0; i < getStartDate().length -1; i++){
			System.out.print(getStartDate()[i] + "/");
		}
		System.out.println(getStartDate()[i]);
		
		System.out.print("      endDate: ");
		for(i = 0; i < getEndDate().length -1; i++){
			System.out.print(getEndDate()[i] + "/");
		}
		System.out.println(getEndDate()[i]);
		
		System.out.println("      Sections:");
		for(Section section : sections.values()){
			System.out.println("       " + section.getclass());
			section.diplayDetails();
		}
	}
	
}
