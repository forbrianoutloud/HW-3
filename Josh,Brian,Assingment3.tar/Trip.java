import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public abstract class Trip {
	private String tripID;
	private String companyName;
	private int[] startDate;
	private int[] endDate;
	private String[] sequence;
	
	
	
	
	Map<Class,Section> sections = new HashMap<Class,Section>();
	
	public Trip(String companyName, String[] sequence, int[] startDate, int[] endDate, String tripID){
		this.tripID = tripID;
		this.companyName = companyName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sequence = sequence;
	}
	
	public String getID(){
		return this.tripID;
	}
	

	
	public String getCompany(){
		return this.companyName;
	}
	
	/* throws exception if section doesn't exist */
	public Section getSection(Class s) throws IOException{
		if (sections.get(s) != null){
			return sections.get(s);
		}else{
			System.err.println("Error: that section " + s.toString() + " does not exist.");
			throw new IOException();
		}
	}
	
	//Displays details about this trip
	public void diplayDetails(){
		System.out.println("    Trip ID: " + tripID);
		System.out.print("      Route - ");
		int i = 0;
		for(i = 0; i < sequence.length - 1;i++){
			System.out.print(sequence[i] + " -> " );
		}
		System.out.println(sequence[i]);
		
		System.out.print("      StartDate: ");
		for(i = 0; i < startDate.length -1; i++){
			System.out.print(startDate[i] + "/");
		}
		System.out.println(startDate[i]);
		
		System.out.print("      endDate: ");
		for(i = 0; i < endDate.length -1; i++){
			System.out.print(endDate[i] + "/");
		}
		System.out.println(endDate[i]);
		
		System.out.println("      Sections:");
		for(Section section : sections.values()){
			System.out.println("       " + section.getclass());
			section.diplayDetails();
		}
	}
	
	// Finds sections that may be available on this trip
	public void findAvailable(){
		int i;
		System.out.println("    Trip ID: " + tripID);
		System.out.print("    Route - ");

		for(i = 0; i < sequence.length - 1;i++){
			System.out.print(sequence[i] + " -> " );
		}
		System.out.println(sequence[i]);
		System.out.print("    StartDate: ");
		for(i = 0; i < startDate.length -1; i++){
			System.out.print(startDate[i] + "/");
		}
		System.out.println(startDate[i]);
		
		System.out.print("    endDate: ");
		for(i = 0; i < endDate.length -1; i++){
			System.out.print(endDate[i] + "/");
		}
		System.out.println(endDate[i]);
		
		System.out.println("      Sections:");
		for(Section section : sections.values()){
			System.out.println("       " + section.getclass());
			section.findAvailable();
		}
	}
	
	public Map<Class,Section> getSections(){
		return sections;
	}

	public int[] getStartDate() {
		return startDate;
	}
	
	public int[] getEndDate(){
		return endDate;
	}
	
	public String getTripID(){
		return tripID;
	}
	
	public String[] getSequence(){
		return sequence;
	}
	


}
